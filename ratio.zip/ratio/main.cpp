#include "ratio.h"


int main()
{//c'est le new
    cout<<"Bienvenue dans notre programme d\'operations sur les nombres relationnels!"<<endl;
    cout<<"Choisissez une session pour vos operations"<<endl;
    cout<<"1-Rationnels Simples"<<endl;
    cout<<"2-Rationnels Normalises"<<endl;

    int choix;
    cin>>choix;
    while (choix !=1 &&  choix !=2) {
        cout<<" Assurez vous de choisir un nombre entre 1 et 2\n";
        cin>>choix;
    }

    if(choix==1)
    {

        cout<<"Alors les operations sur rationnels simples? Alors let\'s go!"<<endl;
        cout<<"1--Addition entre rationnels"<<endl;
        cout<<"2--Addition d\'un rationnel et d\'un entier "<<endl;
        cout<<"3--Multiplication de deux rationnels"<<endl;
        cout<<"4--Multiplication d\'un rationnel et d\'un entier"<<endl;
        cout<<"5--Division de deux rationnels "<<endl;
        cout<<"6--Division d\'un rationnel et d\'un entier"<<endl;
        cout<<"7--Soustraction de deux rationnels"<<endl;
        cout<<"8--Soustraction d\'un rationnel et d\'un entier"<<endl;
        cout<<"9--L\'inverse d\'un rationnel"<<endl;
        cout<<"10--La normalisation d\'un rationnel "<<endl;
        cout<<"11--Le produit de n nombres rationnels "<<endl;
        cout<<"12--La somme de n nombres rationnels "<<endl;
        cout<<"13--L\'affichage d\'un nombre rationnel sous le format num \/ den"<<endl;
        cout<<"14--La relation d\'ordre sur les rationnels, qui compare deux rationnels r1 et r2 et\n";
        cout<<"         donne 1 si r1 est plus petit que r2, sinon donne 0."<<endl;
        cout<<"15--Le classement des representants reels de n nombres rationnels."<<endl;


        cout<<"Choisissez votre operation"<<endl;
        int choixRS;
        cin>>choixRS;
        while (choixRS<1 || choixRS>15) {
            cout<<" Assurez vous de choisir un nombre entre 1 et 15\n";
            cin>>choixRS;
        }
        if (choixRS==1)
        {

            cout<<"Vous avez choisi l\'addition de deux rationnels.\n";
            cout<<"Rationnel 1\n";
            Rationnel a(Recuperation());
            cout<<"Rationnel 2\n";
            Rationnel b(Recuperation());
            a.Addition(b).Affichage();
         }



        if(choixRS==2)
        {
            cout<<"Vous voulez effectuer l\'addition entre un rationel et un entier reel"<<endl;
            int reel;
            Rationnel ratio(Recuperation());
            cout<<"Et l\'entier? : ";
            cin>>reel;
            ratio.Addition(reel).Affichage();
          }
        if(choixRS==3)
        {
            cout<<"Vous voulez multiplication de deux rationnels\n ";
            cout<<"Rationnel 1\n";
            Rationnel a(Recuperation());
            cout<<"Rationnel 2\n";
            Rationnel b(Recuperation());
            a.Multi(b).Affichage();
        }
        if(choixRS==4)
        {


        cout<<"Vous voulez effectuer la multiplication entre un rationel et un nombre reel"<<endl;
        int reel;
        Rationnel ratio(Recuperation());
        cout<<"Et l\'entier? : ";
        cin>>reel;
        ratio.Multi(reel).Affichage();

        }


        if (choixRS==5)
        {

            cout<<"Vous avez choisi la division de deux rationnels.\n";
            cout<<"Rationnel 1\n";
            Rationnel a(Recuperation());
            cout<<"Rationnel 2\n";
            Rationnel b(Recuperation());
            a.Division(b).Affichage();
         }
        if(choixRS==6)
        {
        cout<<"Vous voulez effectuer la division entre un rationel et un reel"<<endl;
        int reel;
        Rationnel ratio(Recuperation());
        cout<<"Et l\'entier? : ";
        cin>>reel;
        ratio.Division(reel).Affichage();

        }
        if(choixRS==7)
        {
            cout<<"Vous avez choisi la soustraction de deux rationnels.\n";
            cout<<"Rationnel 1\n";
            Rationnel a(Recuperation());
            cout<<"Rationnel 2\n";
            Rationnel b(Recuperation());
            a.Soustraction(b).Affichage();
        }
        if(choixRS==8)
        {
            cout<<"Vous avez choisi la soustraction d\'un rationnel et d\'un entier \n";
            int reel;
            Rationnel c(Recuperation());
             cout<<"Et l\'entier? : ";
             cin>>reel;
            c.Soustraction(reel).Affichage();
        }
        if(choixRS==9)
        {
            cout<<"Vous avez choisi l\'inverse d\'un rationnel \n";
             Rationnel c(Recuperation());
             c.Inverse().Affichage();

        }
        if(choixRS==10)
        {
            cout<<"Vous avez choisi la normalisation d\'un rationnel \n";
            Rationnel c(Recuperation());
            c.Normaliser().Affichage();
        }
        if(choixRS==11)
        {
             cout<<"Vous avez choisi le produit de n nombres rationnels \n";
            Rationnel c;
            int n;
            cout<<" Entrer le nombre de rationnels : ";
            cin>>n;
            c.MultiRationnels(n).Affichage();
        }
        if(choixRS==12)
        {
            cout<<"Vous avez choisi la somme de n nombres rationnels \n";
            Rationnel c;
            int n;
            cout<<" Entrer le nombre de rationnels : ";
            cin>>n;
            c.SommeRationnels(n).Affichage();
        }
        if(choixRS==13)
        {
            cout<<"Vous avez choisi l\'affichage d\'un nombre rationnel sous le format num \/ den \n";
            Rationnel c(Recuperation());
            c.Affichage();
        }
        if(choixRS==14)
        {
            cout<<"Vous avez choisi la relation d\'ordre sur les rationnels, qui compare deux rationnels r1 et r2 et\n";
            cout<<"         donne 1 si r1 est plus petit que r2, sinon donne 0. \n";
            cout<<" Donner le r1:\n";
            Rationnel c(Recuperation());
            cout<<" Donner le r2:\n";
            Rationnel d(Recuperation());
            if(c.Comparaison(d)==0)
            {
                c.Affichage();
                cout<<" > ";
                d.Affichage();
            }else if(c.Comparaison(d)==1)
            {
                c.Affichage();
                cout<<" < ";
                d.Affichage();
                cout<<"\n";
            }

        }
        if(choixRS==15)
        {
            cout<<"Vous avez choisi le classement des representants reels de n nombres rationnels. \n";
            Rationnel c;file:///G:/main.cppIO
            c.Trieuse();

        }


    }

    if(choix==2)
    {
    string retour;
    do{
        cout<<"Les operations sur rationnels Normalises? Alors let\'s go!"<<endl;
        cout<<"1--Addition de deux rationnels normalises"<<endl;
        cout<<"2--Multiplication de deux rationnels normalises"<<endl;
        cout<<"3--Division de deux rationnels normalises"<<endl;
        cout<<"4--Soustraction de deux rationnels normalises"<<endl;
        cout<<"5--L\'affichage d\'un nombre rationnel normalise sous le format num / den"<<endl;

        cout<<"Choisissez votre operation"<<endl;
        int choixRN;
        cin>>choixRN;
            while (choixRN<1 || choixRN>5) {
                cout<<" Assurez vous de choisir un nombre entre 1 et 5\n";
                cin>>choixRN;
    }
            if(choixRN==1)
            {
                cout<<"Vous avez choisi l\'addition de deux rationnel normalises.\n";
                cout<<"Rationnel 1\n";
                RationnelNormalise a(Recuperation());
                cout<<"Rationnel 2\n";
                RationnelNormalise b(Recuperation());
                a.Addition(b).Affichage();
            }
            if(choixRN==2)
            {
                cout<<"Vous avez choisi la multiplication de deux rationnels normalises.\n";
                cout<<"Rationnel 1\n";
                RationnelNormalise a(Recuperation());
                cout<<"Rationnel 2\n";
                RationnelNormalise b(Recuperation());
                a.Multi(b).Affichage();

            }
            if(choixRN==3)
            {
                cout<<"Vous avez choisi la division de deux rationnels normalises.\n";
                cout<<"Rationnel 1\n";
                RationnelNormalise a(Recuperation());
                cout<<"Rationnel 2\n";
                RationnelNormalise b(Recuperation());
                a.Division(b).Affichage();

            }
            if(choixRN==4)
            {
                cout<<"Vous avez choisi la soustraction de deux rationnels normalises.\n";
                cout<<"Rationnel 1\n";
                RationnelNormalise a(Recuperation());
                cout<<"Rationnel 2\n";
                RationnelNormalise b(Recuperation());
                a.Soustraction(b).Affichage();

            }
            if(choixRN==5)
            {
                cout<<"Vous avez choisi l\'affichage d\'un nombre rationnel normalise sous le format num / den.\n";
                RationnelNormalise a(Recuperation());
                a.Affichage();

            }
            cout<<"voulez-vous continuer?";
            cin>>retour;
            }while(retour=="OUI"||retour=="Oui"||retour=="oui");


}



    return 0;
}




