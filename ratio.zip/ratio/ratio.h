#ifndef RATIO_H
#define RATIO_H
#include<iostream>
#include<math.h>
#include<vector>

using namespace std;

struct StructRationnel{//structure
    int num;
    int den;
};

StructRationnel Recuperation();//recuperation du num et du den d'un rationnel
bool verifier(int b);//fonction qui verifie si le denominteur est superieur à 0
int pgcd(int a, int b);//pgcd de deux nombres
void tri(vector<double>tab);//tri d'un tableau

//classe des rationnels

class Rationnel{
private:
    int r[2];

public:
    Rationnel (int tab[2]);
    Rationnel (int num, int den); //prend un tableau contenant deux entiers
    Rationnel (int num); //prend juste le numérateur
    Rationnel ();//prend aucune valeur. Assignation automatique
    Rationnel (StructRationnel toi);//prend une structure
    //operations standard
    Rationnel Addition(Rationnel b);
    Rationnel Addition(int b);
    Rationnel Multi(Rationnel b);
    Rationnel Multi(int b);
    Rationnel Division(Rationnel b);
    Rationnel Division(int b);
    double    Division();
    Rationnel Soustraction(Rationnel b);
    Rationnel Soustraction(int b);
    void      Affichage();//affichage d'un nombre rationnel
    Rationnel Inverse();
    Rationnel Inverse(int b);
    Rationnel Normaliser();
    Rationnel SommeRationnels(int n);
    Rationnel MultiRationnels(int n);
    int       Comparaison(Rationnel b);
    void      Trieuse();


};

//classe des rationnels normalisées
class RationnelNormalise{
private:
    int r[2];

public:
    RationnelNormalise(int tab[2]);
    RationnelNormalise(int num, int den); //prend un tableau contenant deux entiers
    RationnelNormalise(int num); //prend juste le numérateur
    RationnelNormalise();//prend aucune valeur. Assignation automatique
    RationnelNormalise(StructRationnel toi);
    //operations standard
    RationnelNormalise Addition(RationnelNormalise b);
    RationnelNormalise Multi(RationnelNormalise b);
    RationnelNormalise Division(RationnelNormalise b);
    RationnelNormalise Soustraction(RationnelNormalise b);
    void               Affichage();//affichage d'un nombre rationnel
    RationnelNormalise Inverse();
    double             Division();
    int                Comparaison(RationnelNormalise b);
    void               Trieuse();
};

#endif // RATIO_H
